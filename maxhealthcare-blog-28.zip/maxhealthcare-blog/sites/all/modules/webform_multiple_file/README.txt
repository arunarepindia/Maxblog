
-- SUMMARY --
Module Webform Multiple File provides new components for Webform,
that allow to use multiple file uploading. The module uses similar
principles of file field widget, implements all features of
common webform component like validation, export, etc.

-- REQUIREMENTS --
Module depends on Webform and File (core).

-- INSTALLATION --
Just enable module and enjoy with new component 'Multiple file'
for Webform!

-- CONTACT AND CREDITS --
Module was developed by Evgeniy Melnikov:
    - http://www.angarsky.ru/
    - http://drupal.org/user/1683348
