<html>
<head><meta http-equiv="cleartype" content="on" />
	<meta name="MobileOptimized" content="width" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta name="HandheldFriendly" content="true" /></head>
<body>	
<div class="specialties">
<?php global $base_url; ?>
<!-- Navigation Bar Begins -->
<div class="nav-main">

	

    <a class="part part-contact " href="<?php echo $base_url; ?>/contact-us">
			<div class="part-inner part-icon">
				<img class="icon" src="<?php echo $base_url; ?>/img/nav/icon-contact-active.svg">
			</div>
			<div class="part-inner part-description">Contact Us</div>
    </a>
	
	
	<a class="part part-about" href="development/aru/maxhealthcare-blog//about-us">
	<div class="part-inner part-icon">
		<img class="icon" src="<?php echo $base_url; ?>/img/nav/icon-about.svg">
	</div>
	<div class="part-inner part-description">
		About Us
	</div>
	</a>
	
	  		
    <div class="part part-logo">
        <div class="wrapper-logo">
            <div class="part-inner">
                <div class="logo">
                    <a href="<?php echo $base_url; ?>">
                        <img src="<?php echo $base_url; ?>/sites/all/themes/maxhealthcare/images/logo-main.svg">
                       
                    </a>
                </div>
            </div>
        </div>
    </div></div>

<!-- Navigation Bar Ends -->
<!-- ************ -->
<!-- Specialties Panel Begins -->

<div class="panel-specialties panel-specialties-compress"><div class="container-specialty specialty-head">
        <div class="specialty-icon">
            <div class="table-icon">
                <div class="cell-icon">
                    <img class="icon" src="<?php echo $base_url; ?>/sites/all/themes/maxhealthcare/images/specialties/panel-open.svg">
                </div>
            </div>
        </div>
       
	   

    </div>
	
	<ul class="wrapper-specialty ps-container ps-active-y ps-active-x" id="specialtiesPanel" data-ps-id="2f85ffbe-e4b6-508f-f65e-a68d625ddfc8">
        <?php
        $vid = 2;
		$depth = 0;
		$tree = taxonomy_get_tree($vid);
        foreach($tree as $key=>$term) {
		if($term->parents[0]==0) {
		  ?>
        <a class="part part-contact dynamic" href="<?php echo $base_url.'/categories/'.$term->name; ?>; ?>">
        <li class="container-specialty specialty-Bone">
              <div class="specialty-name">
                <div class="table-name">
                   <div class="cell-name"><?php echo $term->name; ?></div>
                </div>
            </div>
            <div class="specialty-pointer">
                <div class="cell-pointer">
                    <div class="pointer-left">

                    </div></div></div>
        </li>
        </a>
		<?php }}?>
  </ul>	

</div>

<!-- Specialties Panel Ends -->


<!-- ************ -->


<!-- Section About Begins -->
<?php $path =current_path(); ?>

<section class="section-specialty">
    <div class="container-content container-content-space">
			
				 <?php //$breadcrumb[] = l(drupal_get_title(), current_path());
				 //$bread = drupal_set_breadcrumb($breadcrumb); if (!empty($breadcrumb)): print $bread; endif;
				 print "<div class='breadcrumb' style='padding: 20px 0 0 0;'>".$breadcrumb."</div>";
				 ?>
             
		<ul class="container-treatments">
					<?php
					print $messages; 
					print render($page['content']);
					?>
		</ul>			
	</div>
    
    
</section>


<!-- Footer Begins -->

<div class="footer footer-space" style="bottom: 0;margin: 0;position: fixed;"><div class="line"></div>
    <div class="wrapper-footer">
        <label class="footer-reserved">
            <a>Care For Life</a>
            &nbsp;|&nbsp;
            <a href="/hospital-locations">hospital locations</a>
        </label>

        <label class="footer-legal">
            © 2015 MAX HEALTHCARE. ALL RIGHTS RESERVED.
            &nbsp;|&nbsp;
            <a href="/disclaimer"> DISCLAIMER</a>
            &nbsp;|&nbsp;
            <a href="/privacy-policy">PRIVACY POLICY</a>
        </label>

        <label class="footer-mobile">
            <a href="/hospital-locations">hospital locations</a>
            &nbsp;|&nbsp;
            <a href="/disclaimer"> DISCLAIMER</a>
            &nbsp;|&nbsp;
            <a href="/privacy-policy">PRIVACY POLICY</a>
        </label>
    </div></div>
</div>
<!-- Footer Ends -->
</body>
</html>